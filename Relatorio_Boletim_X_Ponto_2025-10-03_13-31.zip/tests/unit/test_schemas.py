import pandas as pd

from relatorio_horas.core.schemas import BoletimSchema, PontoSchema


def test_boletim_schema_ok():
    df = pd.DataFrame(
        {
            "DATA": ["01/08/2025"],
            "Funcionário": ["ALICE"],
            "HORA NORMAL": [8.0],
            "H.E.": [0.0],
            "H.E.D.": [0.0],
            "H.E.N.": [0.0],
            "H.E.N.D.": [0.0],
            "H.N.": [0.0],
        }
    )
    df["DATA"] = pd.to_datetime(df["DATA"], dayfirst=True)
    BoletimSchema.validate(df)


def test_ponto_schema_ok():
    df = pd.DataFrame(
        {
            "Data": ["01/08/2025"],
            "Nome": ["ALICE"],
            "Total Normais": [8.0],
            "Total Noturno": [0.0],
            "Extra 50%D": [0.0],
            "Extra 100%D": [0.0],
            "Extra 50%N": [0.0],
            "Extra 100%N": [0.0],
        }
    )
    df["Data"] = pd.to_datetime(df["Data"], dayfirst=True)
    PontoSchema.validate(df)
