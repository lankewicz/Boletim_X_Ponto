from utils.formatadores import formatar_tempo


def _fmt(v, modo):
    try:
        return formatar_tempo(v, modo_decimal=modo, separador_decimal=",")
    except TypeError:
        return formatar_tempo(v, modo_decimal=modo)


def test_formatar_tempo_decimal_positivo():
    out = _fmt(1.5, True)
    assert out in ("1,50", "1.50")


def test_formatar_tempo_decimal_negativo():
    out = _fmt(-2.25, True)
    assert out in ("-2,25", "-2.25")


def test_formatar_tempo_hhmm_positivo():
    assert _fmt(1.5, False) == "01:30"


def test_formatar_tempo_hhmm_negativo():
    assert _fmt(-2.25, False) == "-02:15"
