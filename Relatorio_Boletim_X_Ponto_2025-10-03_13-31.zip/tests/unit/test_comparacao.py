import pandas as pd

from relatorio_horas.core.constants import HEADERS_VIZ, MAP_BOL, MAP_PTO
from relatorio_horas.core.services.comparacao import comparar


def test_comparar_basico():
    dfb = pd.DataFrame(
        {
            "DATA": pd.to_datetime(["2025-08-01"]),
            "Funcionário": ["ALICE"],
            "HORA NORMAL": [8.0],
            "H.E.": [0.0],
            "H.E.D.": [0.0],
            "H.E.N.": [0.0],
            "H.E.N.D.": [0.0],
            "H.N.": [0.0],
        }
    )
    dfp = pd.DataFrame(
        {
            "Data": pd.to_datetime(["2025-08-01"]),
            "Nome": ["ALICE"],
            "Total Normais": [7.0],
            "Total Noturno": [0.0],
            "Extra 50%D": [0.0],
            "Extra 100%D": [0.0],
            "Extra 50%N": [0.0],
            "Extra 100%N": [0.0],
        }
    )

    r = comparar(
        dfb,
        dfp,
        "ALICE",
        pd.Timestamp("2025-08-01"),
        pd.Timestamp("2025-08-01"),
        HEADERS_VIZ,
        MAP_BOL,
        MAP_PTO,
    )

    assert r.totais_b[0] == 8.0
    assert r.totais_p[0] == 7.0
    assert r.totais_d[0] == 1.0
